using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;          // 飛機物件
    public Vector3 offset = new Vector3(0f, 3f, 0f); // 決定相機在飛機後方的距離 (X可以試著改負數或正數)
    public float smoothSpeed = 5f;    // 跟隨平滑度

    void LateUpdate()
    {
        if (target == null) return;

        // 直接用世界座標計算相機的目標位置（不隨旋轉亂晃，徹底解決抖動問題）
        Vector3 targetPosition = target.position + offset;

        // 平滑移動到目標位置
        transform.position = Vector3.Lerp(transform.position, targetPosition, smoothSpeed * Time.deltaTime);

        // 永遠盯著飛機看
        transform.LookAt(target);
    }
}