using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro; // 引入 TextMeshPro 命名空間

public class PlayerController : MonoBehaviour
{
    [Header("移動速度設定")]
    public float moveSpeed = 5f;    
    public float flightSpeed = 5f;
    public float verticalSpeed = 5f;   

    [Header("生命值設定")]
    public int maxLives = 3;
    private int currentLives;

    [Header("UI 介面設定")]
    public GameObject gameOverPanel;       // 遊戲失敗面板
    public GameObject gameCompletePanel;   // 遊戲完成/勝利面板
    public TextMeshProUGUI livesText;      // 顯示剩餘生命的文字 (例如 Lives: 3)

    [Header("音效設定")]
    public AudioSource audioSource;
    public AudioClip flySound;
    public AudioClip crashSound;
    public AudioClip passSound;

    private bool isGameEnded = false; // 用來判定遊戲是否已經結束（包含輸或贏）

    void Start()
    {
        currentLives = maxLives;

        if (audioSource == null)
            audioSource = GetComponent<AudioSource>();

        // 播放持續飛行音效
        if (flySound != null)
        {
            audioSource.clip = flySound;
            audioSource.loop = true;
            audioSource.Play();
        }

        // 初始化 UI 與時間
        if (gameOverPanel != null)
            gameOverPanel.SetActive(false);

        if (gameCompletePanel != null)
            gameCompletePanel.SetActive(false);

        Time.timeScale = 1f;
        UpdateLivesUI();
    }

    void Update()
    {
        if (isGameEnded) return; // 遊戲結束時停止操作

        // 1. 簡單的前進移動
        transform.Translate(Vector3.forward * flightSpeed * Time.deltaTime);

        // 2. 取得左右與上下按鍵輸入
        float moveX = Input.GetAxis("Horizontal"); // A, D 左右
        float vertical = Input.GetAxis("Vertical");   // W, S 上下

        // 3. 根據輸入進行位移與高度調整
        transform.Translate(Vector3.right * moveX * moveSpeed * Time.deltaTime);
        transform.Translate(Vector3.up * vertical * verticalSpeed * Time.deltaTime, Space.World);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (isGameEnded) return;

        // 撞到障礙物
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            StartCoroutine(HandleHitSequence(collision.gameObject));
        }
    }

    IEnumerator HandleHitSequence(GameObject obstacle)
    {
        currentLives--; // 扣除一條命
        UpdateLivesUI(); // 更新文字血量

        if (crashSound != null)
            audioSource.PlayOneShot(crashSound);

        if (currentLives > 0)
        {
            // 還有命，銷毀撞到的障礙物讓飛機繼續飛
            Destroy(obstacle);
            yield return null;
        }
        else
        {
            // 生命歸零，正式遊戲失敗
            isGameEnded = true;

            if (gameOverPanel != null)
                gameOverPanel.SetActive(true);

            // 隱藏飛機外觀
            Renderer[] renderers = GetComponentsInChildren<Renderer>();
            foreach (Renderer r in renderers)
            {
                r.enabled = false;
            }

            // 停止飛行音效並暫停遊戲時間
            if (audioSource.isPlaying)
                audioSource.Stop();

            Time.timeScale = 0f;
        }
    }

    void UpdateLivesUI()
    {
        if (livesText != null)
        {
            livesText.text = "Lives: " + currentLives;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (isGameEnded) return;

        // 順利通過終點 / 關卡完成區域
        if (other.CompareTag("PassZone"))
        {
            isGameEnded = true;

            if (passSound != null)
                audioSource.PlayOneShot(passSound);

            // 顯示遊戲完成面板
            if (gameCompletePanel != null)
            {
                gameCompletePanel.SetActive(true);
            }

            // 停止飛行音效並暫停遊戲
            if (audioSource.isPlaying)
                audioSource.Stop();

            Time.timeScale = 0f;
            Debug.Log("遊戲完成！");
        }
    }

    // 綁定到「重新開始」按鈕的事件
    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}